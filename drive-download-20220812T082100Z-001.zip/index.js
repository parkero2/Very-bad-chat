const express = require('express');
const app = express();
const path = require('path')
const fs = require('fs')

const dataFile = require(path.join(__dirname + '/data.json'))

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname+"/index.html"))
})

app.get('/GetData', (req, res) => {
    res.sendFile(path.join(__dirname, "/data.json"))
})

console.log("E")

app.post('/send', (req, res) => {
    console.log(req.headers.data)
    dataFile.data.push(req.headers.data)
    if (dataFile["data"].length > 50) {
        dataFile["data"].pop(0)
    }
    fs.writeFile(path.join(__dirname + '/data.json'), JSON.stringify(dataFile, null, 2), function (err) {
        console.log(err)
    });
});

app.get('/wipe', (req, res) => {
    if (req.headers.auth == "Kukki") {
        dataFile["data"] = [];
        fs.writeFile(path.join(__dirname + '/data.json'), JSON.stringify(dataFile, null, 2), function (err) {
            console.log(err)
        });
    }
})

app.get('/bg', (req, res) => {
    res.sendFile(path.join(__dirname, "/shrek.png"))
})

app.get('/notification', (req,res) => {
	res.sendFile(path.join(__dirname, "notif.mp3"))
})

app.listen(9090, () => {
	console.log("E");
})